CREATE TABLE Urubu (
    idScript int primary key auto_increment,
    nomeScript varchar(150)
);
CREATE TABLE Urubuzinhos (
    idScript_dois int primary key auto_increment,
    nomeScript_dois varchar(150),
    fk_script int,
    FOREIGN KEY (fk_script) REFERENCES Urubu (idScript)
);
CREATE TABLE Urubuzao (
    idScript_tres int primary key auto_increment,
    nomeScript_tres varchar(150),
    fk_script_dois int,
    FOREIGN KEY (fk_script_dois) REFERENCES Urubuzinhos (idScript_dois)
);
#!/bin/bash
# "------------------------------------------------------------------------"
# "===  SCRIPT MAKER CONTAINER - DOCKER MYSQL   |  Autor: Alexandre Gavazzi"
# "------------------------------------------------------------------------"

# "===  Antes de Continuar, certifique-se que:"
# "   1 - O script 'script-docker-mysql.sh' está na mesma pasta que o script.sql"
# "   2 - O terminal bash deve estar aberto na pasta onde está o script.sql e o script-docker-mysql.sh"
# "   3 - Só pode existir 1 arquivo.sql dentro da pasta!"
# "   4 - O arquivo sql não deve ter nenhum 'CREATE DATABASE' pois será criado neste shell script."
# "   5 - O aqruivo sql não pode ter nenhum 'USE <database>' pois o script-docker-mysql.sh também já faz essa função..."
# "   obs: O arquivo sql deve ter somente do primeiro 'CREATE TABLE...' pra baixo..."
echo "Criando Container Docker MySQL" #ECHO PARA AVISO
read -p "Press Enter to continue ..." #ESSE COMANDO SERVE PARA ASSOCIAR O QUE VAI SER DIGITADO A SEGUIR A UMA VARIÁVEL, MAS IMPLEMENTEI PARA FICAR ESPERANDO UM PRESSIONAR DO ENTER.

#Porta do Banco de Dados (PORTA OFICIAL DO MYSQL 3306, MAS PODE MUDAR...)
portaBanco="3306"

#Nome do Banco de Dados
nomeBanco="urubu100"

#Nome do Container Docker
nomeContainer="ContainerDosUrubu"

#Senha do ROOT do Banco Obs:root é um usuário padrão do Banco.
senhaRootBanco="urubu100"

#Crie um usuário qualquer para ter como secundário.
userBanco="urubu100"

#Crie uma senha para esse usuário qualquer.
senhaUserBanco="urubu100"

# COMANDO DOCKER PARA CRIAR CONTAINER, UTILIZANDO AS VARIÁVEIS SHELL.
# ESTE COMANDO É O MESMO QUE FOI DISPONIBILIZADO PELA PROFESSORA MARISE, SÓ ESTÁ COM MAIS 2 VARIÁVEIS DE PONTO DE PARTIDO DO CONTAINER, PARA CRIAR UM USUÁRIO QUALQUER E UMA SENHA PARA O MESMO...
docker run -d -p $portaBanco:3306 --name $nomeContainer -e "MYSQL_DATABASE=$nomeBanco" -e "MYSQL_ROOT_PASSWORD=$senhaRootBanco" -e "MYSQL_USER=$userBanco" -e "MYSQL_PASSWORD=$senhaUserBanco" mysql:5.7

echo "Aguarde 20 Segundos (Inicializando Container...)" #ECHO PARA AVISO
sleep 20                                                #ESSE COMANDO SHELL MANDA ESPERAR 20 SEGUNDOS PARA CONTINUAR O SCRIPT.
read -p "Press Enter to continue ..."                   #ESSE COMANDO SERVE PARA ASSOCIAR O QUE VAI SER DIGITADO A SEGUIR A UMA VARIÁVEL, MAS IMPLEMENTEI PARA FICAR ESPERANDO UM PRESSIONAR DO ENTER.

# ABAIXO TEMOS UMA VARIÁVEL SQL PARA GUARDA O NOME DO ARQUIVO.SQL QUE VAI SER INSERIDO DENTRO DO BANCO MYSQL DOCKER...
# ARQUIVO SQL / ABAIXO SÓ COLOCAR O NOME DO ARQUIVO
# OBS: O ARQUIVO DEVERÁ ESTAR NA MESMA PASTA QUE O script-docker-mysql.sh OU SEJA, MESMA PASTA QUE ESTÁ ESSE SCRIPT.
file_sql="sqlteste.sql"

# COMANDO DOCKER PARA INSERIR
# EXPLICANDO COMANDO A SEGUIR...
# docker  --------(para usar um comando do docker)
# exec  ----------(para fazer uma execução)
# -i  ------------(para interagir com o container docker)
# $nomeContainer  (para mencionar o container ao qual vamos interagir)
# sh   -----------(para dizer que vamos querer executar algo em shell dentro do container)
# -c   -----------(para dizer que o que vamos querer executar em shell é um c de command)
# exec   ---------(para fazer uma execução)
# '  -------------(inicio das aspas para separar o comando que vem a seguir...)
# mysql   --------(para fazer o comando que entra dentro do mysql via command line interface)
# -uroot   -------(para passando que vamos entrar no mysql cli com o usuário tal...)
# -proot   -------(para passando a credencial de senha do usuário tal para acessar o banco..)
# $nomeBanco  ----(para passando o banco que vamos querer ter acesso com o usuário mencionado obs:Usei a variável shell que já tem como valor o nosso banco 'teste')
# '  -------------(fim das aspas para separar o comando que vem a seguir...)
# <  -------------(para dizer ao docker para executar este proximo arquivo.sql dentro do banco que mencionamos e entramos anteriormente)
# '  -------------(inicio das aspas para mencionar um arquivo.sql)
# $file_sql  -----(para arquivo.sql que vai ser inserido dentro do banco)
# '  -------------(fim das aspas para finalizar a menção ao arquivo.sql)
docker exec -i $nomeContainer sh -c 'exec mysql -uroot -proot '$nomeBanco'' <"$file_sql"

#
# "===  FIM DO SCRIPT 'script-docker-mysql.sh', OBRIGADO. ==="
# "----------------------------------------------------------"
# "===                    CRÉDITOS                        ==="
# "===                 Alexandre Gavazzi                  ==="
# "----------------------------------------------------------"